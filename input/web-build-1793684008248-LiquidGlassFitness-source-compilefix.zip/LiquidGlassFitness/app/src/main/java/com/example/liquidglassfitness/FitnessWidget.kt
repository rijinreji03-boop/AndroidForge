package com.example.liquidglassfitness

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.GlanceTheme
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.layout.*
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.text.FontWeight
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Glass = ColorProvider(0xCC26384A.toInt())
private val White = ColorProvider(0xFFF6F8FC.toInt())
private val Muted = ColorProvider(0xFFB8C7D9.toInt())
private val Green = ColorProvider(0xFF9BFF76.toInt())

class FitnessWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = FitnessWidget()
}

class FitnessWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val prefs = context.getSharedPreferences("fitness", Context.MODE_PRIVATE)
        val steps = prefs.getLong("steps", 0L)
        val calories = prefs.getInt("calories", 0)
        val heart = prefs.getInt("heart", -1)
        provideContent {
            GlanceTheme {
                Row(
                    modifier = GlanceModifier.fillMaxSize().background(Glass).cornerRadius(28.dp).padding(12.dp),
                    verticalAlignment = androidx.glance.layout.Alignment.Vertical.CenterVertically
                ) {
                    Column(modifier = GlanceModifier.defaultWeight().background(ColorProvider(0x553B536B)).cornerRadius(20.dp).padding(10.dp), verticalAlignment = androidx.glance.layout.Alignment.Vertical.CenterVertically) {
                        Text("👟  STEPS", style = TextStyle(color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium))
                        Text(if (steps > 0) String.format("%,d", steps) else "—", style = TextStyle(color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold))
                        Text("of 10,000", style = TextStyle(color = Green, fontSize = 11.sp))
                        Spacer(GlanceModifier.height(5.dp))
                        Row(GlanceModifier.fillMaxWidth().height(4.dp), horizontalAlignment = androidx.glance.layout.Alignment.Horizontal.Start) {
                            for (segment in 0 until 10) {
                                Box(
                                    GlanceModifier.defaultWeight().height(4.dp)
                                        .background(if (steps >= (segment + 1) * 1000L) Green else ColorProvider(0x557E8FA2))
                                        .cornerRadius(2.dp)
                                ) {}
                                if (segment < 9) Spacer(GlanceModifier.width(2.dp))
                            }
                        }
                    }
                    Spacer(GlanceModifier.width(7.dp))
                    Column(modifier = GlanceModifier.defaultWeight().background(ColorProvider(0x553B536B)).cornerRadius(20.dp).padding(10.dp), verticalAlignment = androidx.glance.layout.Alignment.Vertical.CenterVertically) {
                        Text("🔥  ACTIVE", style = TextStyle(color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium))
                        Text(if (calories > 0) "$calories" else "—", style = TextStyle(color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold))
                        Text("kcal burned", style = TextStyle(color = Green, fontSize = 11.sp))
                    }
                    Spacer(GlanceModifier.width(7.dp))
                    Column(modifier = GlanceModifier.defaultWeight().background(ColorProvider(0x553B536B)).cornerRadius(20.dp).padding(10.dp), verticalAlignment = androidx.glance.layout.Alignment.Vertical.CenterVertically) {
                        Text("♥  HEART RATE", style = TextStyle(color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Medium))
                        Text(if (heart > 0) "$heart" else "—", style = TextStyle(color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold))
                        Text("BPM · latest", style = TextStyle(color = Green, fontSize = 11.sp))
                        Text("⌁  ·  ⌁  ·  ⌁", style = TextStyle(color = Green, fontSize = 12.sp))
                    }
                }
            }
        }
    }
}
