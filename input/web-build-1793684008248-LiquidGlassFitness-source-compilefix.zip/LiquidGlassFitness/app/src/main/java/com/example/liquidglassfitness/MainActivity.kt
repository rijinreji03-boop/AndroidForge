package com.example.liquidglassfitness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.work.*
import androidx.lifecycle.lifecycleScope
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

val HealthPermissionsNeeded = setOf(
    HealthPermission.getReadPermission(StepsRecord::class),
    HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
    HealthPermission.getReadPermission(HeartRateRecord::class)
)

class MainActivity : ComponentActivity() {
    private val client by lazy { HealthConnectClient.getOrCreate(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var status by remember { mutableStateOf("Connect to Health Connect to load your metrics.") }
            val permissionLauncher = rememberLauncherForActivityResult(
                PermissionController.createRequestPermissionResultContract()
            ) { granted ->
                if (granted.containsAll(HealthPermissionsNeeded)) {
                    status = "Connected. Reading your latest data…"
                    enqueueRefresh()
                    lifecycleScopeRefresh { refreshHealthData(this@MainActivity, client) }
                } else status = "Some permissions were not granted. You can retry below."
            }
            MaterialTheme {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF111C2A), Color(0xFF273B52)))).padding(24.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.align(Alignment.Center)) {
                        Text("LIQUID GLASS FITNESS", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                        Text("Steps · Active calories · Heart rate", color = Color(0xFFDCE7F5))
                        Text(status, color = Color(0xFFEAF2FA))
                        Button(onClick = { permissionLauncher.launch(HealthPermissionsNeeded) }, shape = RoundedCornerShape(18.dp)) { Text("Connect Health Connect") }
                        OutlinedButton(onClick = { enqueueRefresh(); lifecycleScopeRefresh { refreshHealthData(this@MainActivity, client) }; status = "Refreshing data…" }) { Text("Refresh widget") }
                        Text("Add the Liquid Glass Fitness widget from your home-screen widget picker after connecting.", color = Color(0xFFB9C9D9), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    private fun enqueueRefresh() {
        val request = PeriodicWorkRequestBuilder<FitnessRefreshWorker>(30, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("fitness-refresh", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}

// Runs suspend refresh work on the activity lifecycle scope without blocking the UI.
private fun ComponentActivity.lifecycleScopeRefresh(block: suspend () -> Unit) {
    lifecycleScope.launch { runCatching { block() } }
}

suspend fun refreshHealthData(context: android.content.Context, client: HealthConnectClient) {
    val granted = client.permissionController.getGrantedPermissions()
    if (!granted.containsAll(HealthPermissionsNeeded)) return
    val zone = ZoneId.systemDefault()
    val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
    val now = Instant.now()
    val steps = runCatching {
        client.aggregate(androidx.health.connect.client.request.AggregateRequest(
            metrics = setOf(StepsRecord.COUNT_TOTAL),
            timeRangeFilter = androidx.health.connect.client.time.TimeRangeFilter.between(start, now)
        ))[StepsRecord.COUNT_TOTAL] ?: 0L
    }.getOrDefault(0L)
    val calories = runCatching {
        client.aggregate(androidx.health.connect.client.request.AggregateRequest(
            metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
            timeRangeFilter = androidx.health.connect.client.time.TimeRangeFilter.between(start, now)
        ))[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories?.toInt() ?: 0
    }.getOrDefault(0)
    val hrStart = now.minus(24, ChronoUnit.HOURS)
    val heart = runCatching {
        client.readRecords(androidx.health.connect.client.request.ReadRecordsRequest(
            recordType = HeartRateRecord::class,
            timeRangeFilter = androidx.health.connect.client.time.TimeRangeFilter.between(hrStart, now),
            ascendingOrder = false,
            pageSize = 100
        )).records.asSequence().flatMap { it.samples.asSequence() }.maxByOrNull { it.time }?.beatsPerMinute?.toInt()
    }.getOrNull()
    context.getSharedPreferences("fitness", android.content.Context.MODE_PRIVATE).edit()
        .putLong("steps", steps).putInt("calories", calories)
        .putInt("heart", heart ?: -1).putLong("heart_time", now.toEpochMilli()).apply()
    FitnessWidget().updateAll(context)
}

class FitnessRefreshWorker(context: android.content.Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val client = HealthConnectClient.getOrCreate(applicationContext)
        refreshHealthData(applicationContext, client)
        Result.success()
    } catch (_: Exception) { Result.retry() }
}
