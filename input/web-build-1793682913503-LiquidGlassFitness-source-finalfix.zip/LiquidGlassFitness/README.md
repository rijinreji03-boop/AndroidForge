# Liquid Glass Fitness (Android starter project)

A starter Android home-screen widget for Vivo X300 Pro. The widget has a wide frosted-glass-style panel for:
- Today's steps / 10,000 goal
- Active calories burned
- Latest available heart-rate sample

It reads data locally from Health Connect and requests only the three relevant data permissions. It does not upload health data to a server.

## Important status
This is **source code, not an installable APK**. It has not been compiled or tested on a physical Vivo device in this environment. Open the project in Android Studio, sync Gradle, resolve any SDK/version prompts, build and install it on the phone. The widget's actual transparency can be limited by Android launcher widget rendering; this uses a translucent glass-like panel rather than true live background blur.

## How to try it
1. Install/update Health Connect on the phone.
2. Open this project in Android Studio (recent version with Android SDK 35).
3. Build and install the `app` module.
4. Open **Liquid Glass Fitness**, tap **Connect Health Connect**, and grant Steps, Active calories burned, and Heart rate.
5. Long-press the home screen → Widgets → Liquid Glass Fitness → add the wide widget.
6. Allow background data access if prompted/available. Updates are best-effort and subject to Health Connect sync, Android background limits, and Vivo battery management.

## Notes
- Google Health/Fitbit and Google Fit data appears only if those apps write/sync the corresponding records into Health Connect. This app cannot read private data directly from those apps.
- Active calories may be blank/zero until the watch/app has written records and permissions are granted.
- Heart-rate trend is represented by a simple decorative sparkline placeholder in this starter; it currently shows the latest sample rather than plotting a true historical series.
- For Google Play distribution, a complete privacy-policy URL and Health Connect Play Console declarations would be required.
