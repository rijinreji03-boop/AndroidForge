package com.example.liquidglassfitness

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.widget.RemoteViews

/** Native RemoteViews widget: avoids a framework composition loading placeholder on launchers that
 *  do not finish the initial widget composition reliably. */
class FitnessWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { FitnessWidgetRenderer.render(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == AppWidgetManager.ACTION_APPWIDGET_UPDATE || intent.action == ACTION_REFRESH) {
            FitnessWidgetRenderer.updateAll(context)
        }
    }

    companion object { const val ACTION_REFRESH = "com.example.liquidglassfitness.REFRESH_WIDGET" }
}

object FitnessWidgetRenderer {
    fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, FitnessWidgetReceiver::class.java))
        ids.forEach { render(context, manager, it) }
    }

    fun render(context: Context, manager: AppWidgetManager, id: Int) {
        val prefs = context.getSharedPreferences("fitness", Context.MODE_PRIVATE)
        val steps = prefs.getLong("steps", 0L).coerceAtLeast(0L)
        val calories = prefs.getInt("calories", 0).coerceAtLeast(0)
        val heart = prefs.getInt("heart", -1)
        val trend = prefs.getString("heart_trend", "").orEmpty().split(',').mapNotNull { it.toFloatOrNull() }
        val updated = prefs.getLong("updated_at", 0L)
        val views = RemoteViews(context.packageName, R.layout.widget_fitness)
        views.setTextViewText(R.id.steps_value, String.format("%,d", steps))
        views.setTextViewText(R.id.calories_value, if (updated > 0L) calories.toString() else "—")
        views.setTextViewText(R.id.heart_value, if (heart > 0) heart.toString() else "—")
        views.setTextViewText(R.id.updated_label, if (updated > 0L) "Updated ${android.text.format.DateUtils.getRelativeTimeSpanString(updated, System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS)}" else "Open app to connect health data")
        views.setImageViewBitmap(R.id.steps_ring, drawRing(context, steps))
        views.setImageViewBitmap(R.id.heart_chart, drawHeartChart(context, trend))
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.widget_root, open)
        manager.updateAppWidget(id, views)
    }

    private fun drawRing(context: Context, steps: Long): Bitmap {
        val density = context.resources.displayMetrics.density
        val size = (72f * density).toInt().coerceAtLeast(72)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val stroke = 7f * density
        val inset = stroke / 2f + 2f * density
        val rect = RectF(inset, inset, size - inset, size - inset)
        p.style = Paint.Style.STROKE; p.strokeWidth = stroke; p.strokeCap = Paint.Cap.ROUND
        p.color = 0x557E91A5
        canvas.drawArc(rect, -90f, 360f, false, p)
        p.color = 0xFF9CFF78.toInt()
        canvas.drawArc(rect, -90f, 360f * (steps.coerceAtMost(10000L) / 10000f), false, p)
        p.style = Paint.Style.FILL; p.color = 0xFFF7FAFF.toInt(); p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); p.textSize = 16f * density
        canvas.drawText(compact(steps), size / 2f, size / 2f + 5f * density, p)
        return bitmap
    }

    private fun drawHeartChart(context: Context, values: List<Float>): Bitmap {
        val density = context.resources.displayMetrics.density
        val w = (78f * density).toInt().coerceAtLeast(78)
        val h = (24f * density).toInt().coerceAtLeast(24)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9CFF78.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * density; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        if (values.size >= 2) {
            val lo = values.minOrNull() ?: 0f; val hi = values.maxOrNull() ?: 1f
            val range = (hi - lo).coerceAtLeast(1f)
            val pad = 3f * density
            val path = android.graphics.Path()
            values.forEachIndexed { i, v ->
                val x = pad + i * ((w - 2 * pad) / (values.size - 1).toFloat())
                val y = h - pad - ((v - lo) / range) * (h - 2 * pad)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, p)
        } else {
            p.style = Paint.Style.FILL
            canvas.drawCircle(w / 2f, h / 2f, 2.5f * density, p)
        }
        return bitmap
    }

    private fun compact(n: Long): String = when {
        n >= 10000 -> "${n / 1000}k"
        else -> n.toString()
    }
}
