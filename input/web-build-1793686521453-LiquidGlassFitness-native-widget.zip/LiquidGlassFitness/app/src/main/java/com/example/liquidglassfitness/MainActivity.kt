package com.example.liquidglassfitness

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.work.*
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit

val HealthPermissionsNeeded = setOf(
    HealthPermission.getReadPermission(StepsRecord::class),
    HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
    HealthPermission.getReadPermission(HeartRateRecord::class)
)

class MainActivity : ComponentActivity() {
    private val client by lazy { HealthConnectClient.getOrCreate(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var status by remember { mutableStateOf("Connect Health Connect to load today's metrics.") }
            var busy by remember { mutableStateOf(false) }
            var steps by remember { mutableStateOf("—") }
            var calories by remember { mutableStateOf("—") }
            var heart by remember { mutableStateOf("—") }
            val scope = rememberCoroutineScope()

            suspend fun loadMetrics() {
                busy = true
                status = "Reading today's health data…"
                try {
                    val granted = client.permissionController.getGrantedPermissions()
                    if (!granted.containsAll(HealthPermissionsNeeded)) {
                        status = "Health Connect is connected, but one or more data permissions are missing. Tap Connect to review them."
                    } else {
                        refreshHealthData(this@MainActivity, client)
                        val p = getSharedPreferences("fitness", MODE_PRIVATE)
                        steps = String.format("%,d", p.getLong("steps", 0L))
                        calories = p.getInt("calories", 0).toString()
                        heart = p.getInt("heart", -1).takeIf { it > 0 }?.toString() ?: "—"
                        status = if (p.getLong("updated_at", 0L) > 0) "Data refreshed successfully." else "Connected, but no matching records were returned yet. Check that your watch data has synced to Health Connect."
                        scheduleRefresh()
                    }
                } catch (e: Exception) {
                    status = "Couldn't read Health Connect: ${e.localizedMessage ?: e.javaClass.simpleName}"
                } finally { busy = false }
            }

            val permissionLauncher = rememberLauncherForActivityResult(
                PermissionController.createRequestPermissionResultContract()
            ) { granted ->
                if (granted.containsAll(HealthPermissionsNeeded)) scope.launch { loadMetrics() }
                else status = "Some permissions were not granted. Steps, calories and heart rate each need read access."
            }

            MaterialTheme {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF111C2A), Color(0xFF273B52)))).padding(24.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.align(Alignment.Center)) {
                        Text("LIQUID GLASS FITNESS", style = MaterialTheme.typography.headlineSmall, color = Color.White)
                        Text("Steps  ·  Active calories  ·  Heart rate", color = Color(0xFFDCE7F5))
                        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                            Metric("STEPS", steps); Metric("ACTIVE KCAL", calories); Metric("HEART BPM", heart)
                        }
                        Text(status, color = Color(0xFFEAF2FA))
                        Button(enabled = !busy, onClick = { permissionLauncher.launch(HealthPermissionsNeeded) }, shape = RoundedCornerShape(18.dp)) { Text("Connect Health Connect") }
                        OutlinedButton(enabled = !busy, onClick = { scope.launch { loadMetrics() } }) { Text(if (busy) "Refreshing…" else "Refresh widget") }
                        Text("After connecting, add the wide Liquid Glass Fitness widget from your home-screen widget picker. Tap the widget to open this app.", color = Color(0xFFB9C9D9), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            LaunchedEffect(Unit) {
                val granted = runCatching { client.permissionController.getGrantedPermissions() }.getOrDefault(emptySet())
                if (granted.containsAll(HealthPermissionsNeeded)) loadMetrics()
            }
        }
    }

    private fun scheduleRefresh() {
        val request = PeriodicWorkRequestBuilder<FitnessRefreshWorker>(30, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("fitness-refresh", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}

suspend fun refreshHealthData(context: android.content.Context, client: HealthConnectClient) {
    val granted = client.permissionController.getGrantedPermissions()
    require(granted.containsAll(HealthPermissionsNeeded)) { "Missing Health Connect read permissions" }
    val zone = ZoneId.systemDefault()
    val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
    val now = Instant.now()
    val steps = client.aggregate(AggregateRequest(
        metrics = setOf(StepsRecord.COUNT_TOTAL),
        timeRangeFilter = TimeRangeFilter.between(start, now)
    ))[StepsRecord.COUNT_TOTAL] ?: 0L
    val calories = client.aggregate(AggregateRequest(
        metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
        timeRangeFilter = TimeRangeFilter.between(start, now)
    ))[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories?.toInt() ?: 0

    val hrStart = now.minus(24, ChronoUnit.HOURS)
    val heartRecords = client.readRecords(ReadRecordsRequest(
        recordType = HeartRateRecord::class,
        timeRangeFilter = TimeRangeFilter.between(hrStart, now),
        ascendingOrder = true,
        pageSize = 500
    )).records
    val samples = heartRecords.flatMap { it.samples }.sortedBy { it.time }
    val latest = samples.lastOrNull()?.beatsPerMinute?.toInt() ?: -1
    val trend = samples.takeLast(24).map { it.beatsPerMinute.toInt() }.joinToString(",")
    context.getSharedPreferences("fitness", android.content.Context.MODE_PRIVATE).edit()
        .putLong("steps", steps).putInt("calories", calories)
        .putInt("heart", latest).putString("heart_trend", trend)
        .putLong("updated_at", now.toEpochMilli()).apply()
    FitnessWidgetRenderer.updateAll(context)
}

class FitnessRefreshWorker(context: android.content.Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val client = HealthConnectClient.getOrCreate(applicationContext)
        refreshHealthData(applicationContext, client)
        Result.success()
    } catch (e: SecurityException) { Result.failure() }
      catch (_: Exception) { Result.retry() }
}

@Composable
private fun Metric(label: String, value: String) {
    Column(Modifier.background(Color(0x553B536B), RoundedCornerShape(14.dp)).padding(10.dp)) {
        Text(label, color = Color(0xFFB8C7D9), style = MaterialTheme.typography.labelSmall)
        Text(value, color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}
